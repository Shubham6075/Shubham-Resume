package com.acl.tenant.gateway.filter;

import com.acl.tenant.gateway.entity.AuthConfig;
import com.acl.tenant.gateway.exception.CatsCustomException;
import com.acl.tenant.gateway.util.EncryptDecryptUtil;
import com.acl.tenant.gateway.util.JwtUtils;
import com.acl.tenant.gateway.util.TokenService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.impl.DefaultClaims;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.core.io.buffer.DataBufferFactory;
import org.springframework.http.server.RequestPath;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.web.server.MockServerWebExchange;
import org.springframework.test.context.event.annotation.BeforeTestMethod;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.awt.image.DataBuffer;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class AuthPreFilterTest {

	@InjectMocks
	private AuthPreFilter factory;

//    private ServerWebExchange exchange;

	@Mock
	private JwtUtils jwtUtils;

	@Mock
	private TokenService tokenService;

	@Mock
	private AuthConfig authConfig;

	@Mock
	ServerHttpRequest request;

	@Mock
	ServerHttpResponse response1;

	@Mock
	ObjectMapper objectMapper;

	private static MockedStatic<EncryptDecryptUtil> encryptDecryptUtil;

	@Mock
	URI mUri;

	@BeforeAll
	static void setUp() {
		encryptDecryptUtil = Mockito.mockStatic(EncryptDecryptUtil.class);

	}

	@AfterAll
	static void closeAfter() {
		encryptDecryptUtil.close();

	}

//	@Test
	void filter() throws URISyntaxException, JsonProcessingException {

		ServerWebExchange exchange = Mockito.mock(ServerWebExchange.class);
		ServerHttpRequest request = Mockito.mock(ServerHttpRequest.class);
		ServerHttpResponse response = Mockito.mock(ServerHttpResponse.class);
		GatewayFilterChain gatewayFilterChain = Mockito.mock(GatewayFilterChain.class);
		ServerHttpRequest.Builder builder = Mockito.mock(ServerHttpRequest.Builder.class);

		Claims claims = new DefaultClaims();

		String[] urlsArr = new String[2];
		urlsArr[0] = "asdd";

		Mockito.when(authConfig.getSecretkey()).thenReturn("asdf");
		String[] arr = new String[1];
		arr[0] = "dfghjkl";
		Mockito.when(authConfig.getExcludeUrls()).thenReturn(arr);
		encryptDecryptUtil.when(() -> EncryptDecryptUtil.decrypt(Mockito.any(), Mockito.any()))
				.thenReturn("asdfghjkljhgf");
		LinkedHashMap<String, Boolean> map = new LinkedHashMap<>();

		map.put("deskTopApp", true);
		claims.put("payload", map);

		URI uri = new URI("pro_watch");

		LinkedHashMap<String,String> respMap = new LinkedHashMap<>();
		respMap.put("role","sdsd");


		Mockito.when(exchange.getRequest()).thenReturn(request);
		Mockito.when(exchange.getResponse()).thenReturn(response);
//		Mockito.when(request.mutate()).thenReturn(builder);
//		Mockito.when(builder.header(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(builder);

		Mockito.when(request.getURI()).thenReturn(uri);
		RequestPath requestPath = Mockito.mock(RequestPath.class);
		requestPath.modifyContextPath("dfghjkl");

		Mockito.when(request.getPath()).thenReturn(requestPath);

		Mockito.when(jwtUtils.getTokenFromRequest(request)).thenReturn("jwtParser1");
		Mockito.when(jwtUtils.validateJwtToken(ArgumentMatchers.anyString(), ArgumentMatchers.any()))
				.thenReturn(new CatsCustomException("101", "success", "success"));
		Mockito.when(jwtUtils.getUserNameFromJwtToken(ArgumentMatchers.anyString())).thenReturn("success");
		Mockito.when(jwtUtils.getAllClaimsFromToken(ArgumentMatchers.anyString())).thenReturn(claims);
		Mockito.when(tokenService.validateToken(ArgumentMatchers.anyString(), ArgumentMatchers.anyString()))
				.thenReturn(new CatsCustomException("101", "success", "success"));
		Mono<Void> mono = factory.filter(exchange, gatewayFilterChain);
		assertNull(mono);
	}

	@Test
	void filter1() throws URISyntaxException {
		ServerWebExchange exchange = Mockito.mock(ServerWebExchange.class);
		GatewayFilterChain gatewayFilterChain = Mockito.mock(GatewayFilterChain.class);
		ServerHttpRequest.Builder builder = Mockito.mock(ServerHttpRequest.Builder.class);
		Claims claims = new DefaultClaims();
		LinkedHashMap<String, Boolean> map = new LinkedHashMap<>();
		map.put("deskTopApp", true);
		claims.put("payload", map);

		Mockito.lenient().when(authConfig.getSecretkey()).thenReturn("asdf");
		String[] arr = new String[1];
		arr[0] = "dfghjkl";
		Mockito.lenient().when(authConfig.getExcludeUrls()).thenReturn(arr);
		encryptDecryptUtil.when(() -> EncryptDecryptUtil.decrypt(Mockito.any(), Mockito.any()))
				.thenReturn("asdfghjkljhgf");

		URI uri = new URI("/desktop/app/");
		Mockito.lenient().when(exchange.getRequest()).thenReturn(request);
		Mockito.lenient().when(exchange.getResponse()).thenReturn(response1);
		Mockito.lenient().when(request.mutate()).thenReturn(builder);
		Mockito.lenient().when(builder.header(ArgumentMatchers.anyString(), ArgumentMatchers.anyString()))
				.thenReturn(builder);
		Mockito.lenient().when(request.getURI()).thenReturn(uri);
		Mockito.lenient().when(authConfig.getTokenttl()).thenReturn(300L);
		Mockito.lenient().when(jwtUtils.getTokenFromRequest(request)).thenReturn("jwtParser1");
		Mockito.lenient().when(jwtUtils.validateJwtToken(ArgumentMatchers.anyString(), ArgumentMatchers.any()))
				.thenReturn(new CatsCustomException("101", "success-1", "success_1"));
		Mockito.lenient().when(jwtUtils.getUserNameFromJwtToken(ArgumentMatchers.anyString())).thenReturn("success");
		Mockito.lenient().when(jwtUtils.getAllClaimsFromToken(ArgumentMatchers.anyString())).thenReturn(claims);
		Mockito.lenient().when(tokenService.validateToken(ArgumentMatchers.anyString(), ArgumentMatchers.anyString()))
				.thenReturn(new CatsCustomException("101", "success", "success"));
		Mono<Void> mono = factory.filter(exchange, gatewayFilterChain);
		assertNull(mono);
	}

    @Test
	void filter2() throws URISyntaxException {
		ServerHttpResponse serverHttpResponse = Mockito.mock(ServerHttpResponse.class);
		ServerWebExchange exchange = Mockito.mock(ServerWebExchange.class);
		GatewayFilterChain gatewayFilterChain = Mockito.mock(GatewayFilterChain.class);
		ServerHttpRequest.Builder builder = Mockito.mock(ServerHttpRequest.Builder.class);
		Claims claims = new DefaultClaims();
		LinkedHashMap<String, Boolean> map = new LinkedHashMap<>();
		map.put("deskTopApp", false);
		claims.put("payload", map);

		
		Mockito.lenient().when(authConfig.getSecretkey()).thenReturn("asdf");
		String[] arr = new String[1];
		arr[0] = "dfghjkl";
		Mockito.lenient().when(authConfig.getExcludeUrls()).thenReturn(arr);
		encryptDecryptUtil.when(() -> EncryptDecryptUtil.decrypt(Mockito.any(), Mockito.any()))
				.thenReturn("asdfghjkljhgf");
		
		DataBuffer dataBuffer = Mockito.mock(DataBuffer.class);
		DataBufferFactory dataBufferFactory = Mockito.mock(DataBufferFactory.class);
		byte[] b = new byte[10];

		URI uri = new URI("/iprocess/");
		Mockito.when(exchange.getRequest()).thenReturn(request);
		Mockito.when(request.mutate()).thenReturn(builder);
		Mockito.when(builder.header(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(builder);
		Mockito.when(request.getURI()).thenReturn(uri);
		Mockito.when(exchange.getResponse()).thenReturn(serverHttpResponse);
		Mockito.when(serverHttpResponse.bufferFactory()).thenReturn(dataBufferFactory);
		Mockito.when(dataBufferFactory.wrap(b)).thenReturn(null);
		Mockito.when(authConfig.getTokenttl()).thenReturn(300L);
		Mockito.when(jwtUtils.getTokenFromRequest(request)).thenReturn("jwtParser1");
		Mockito.when(jwtUtils.validateJwtToken(ArgumentMatchers.anyString(), ArgumentMatchers.any()))
				.thenReturn(new CatsCustomException("101", "success", "success"));
		Mockito.when(jwtUtils.getUserNameFromJwtToken(ArgumentMatchers.anyString())).thenReturn("success");
		Mockito.when(jwtUtils.getAllClaimsFromToken(ArgumentMatchers.anyString())).thenReturn(claims);
		Mockito.when(tokenService.validateToken(ArgumentMatchers.anyString(), ArgumentMatchers.anyString()))
				.thenReturn(new CatsCustomException("101", "failed", "failed"));
		Mono<Void> mono = factory.filter(exchange, gatewayFilterChain);
		assertNull(mono);
	}

    @Test
	void filter3() throws URISyntaxException {
		ServerHttpResponse serverHttpResponse = Mockito.mock(ServerHttpResponse.class);
		ServerWebExchange exchange = Mockito.mock(ServerWebExchange.class);
		GatewayFilterChain gatewayFilterChain = Mockito.mock(GatewayFilterChain.class);
		ServerHttpRequest.Builder builder = Mockito.mock(ServerHttpRequest.Builder.class);
		Claims claims = new DefaultClaims();
		LinkedHashMap<String, Boolean> map = new LinkedHashMap<>();
		map.put("deskTopApp", true);
		claims.put("payload", map);
		
		Mockito.lenient().when(authConfig.getSecretkey()).thenReturn("asdf");
		String[] arr = new String[1];
		arr[0] = "dfghjkl";
		Mockito.lenient().when(authConfig.getExcludeUrls()).thenReturn(arr);
		encryptDecryptUtil.when(() -> EncryptDecryptUtil.decrypt(Mockito.any(), Mockito.any()))
				.thenReturn("asdfghjkljhgf");

		RequestPath requestPath = Mockito.mock(RequestPath.class);
		requestPath.modifyContextPath("dfghjkl");

		Mockito.when(request.getPath()).thenReturn(requestPath);

		
		DataBufferFactory dataBufferFactory = Mockito.mock(DataBufferFactory.class);
		byte[] b = new byte[10];

		URI uri = new URI("/bff/");
		Mockito.lenient().when(exchange.getRequest()).thenReturn(request);
		Mockito.lenient().when(request.mutate()).thenReturn(builder);
		Mockito.lenient().when(builder.header(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(builder);
		Mockito.lenient().when(request.getURI()).thenReturn(uri);
		Mockito.lenient().when(exchange.getResponse()).thenReturn(serverHttpResponse);
		Mockito.lenient().when(serverHttpResponse.bufferFactory()).thenReturn(dataBufferFactory);
		Mockito.lenient().when(dataBufferFactory.wrap(b)).thenReturn(null);
		Mockito.lenient().when(authConfig.getTokenttl()).thenReturn(300L);
		Mockito.lenient().when(jwtUtils.getTokenFromRequest(request)).thenReturn("jwtParser1");
		Mockito.lenient().when(jwtUtils.validateJwtToken(ArgumentMatchers.anyString(), ArgumentMatchers.any()))
		.thenReturn(new CatsCustomException("101", "success", "success"));
        Mockito.lenient().when(jwtUtils.getAllClaimsFromToken(ArgumentMatchers.any())).thenReturn(claims);
        Mockito.lenient().when(tokenService.validateToken(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(new CatsCustomException("101", "success", "success"));
		Mono<Void> mono = factory.filter(exchange, gatewayFilterChain);
		assertNull(mono);
	}

   @Test
	void filter4() throws URISyntaxException {
		ServerHttpResponse serverHttpResponse = Mockito.mock(ServerHttpResponse.class);
		ServerWebExchange exchange = Mockito.mock(ServerWebExchange.class);
		GatewayFilterChain gatewayFilterChain = Mockito.mock(GatewayFilterChain.class);
		ServerHttpRequest.Builder builder = Mockito.mock(ServerHttpRequest.Builder.class);
		Claims claims = new DefaultClaims();
		LinkedHashMap<String, Boolean> map = new LinkedHashMap<>();
		map.put("deskTopApp1", true);
		claims.put("payload", map);
		
		Mockito.lenient().when(authConfig.getSecretkey()).thenReturn("asdf");
		String[] arr = new String[1];
		arr[0] = "dfghjkl";
		Mockito.lenient().when(authConfig.getExcludeUrls()).thenReturn(arr);
		encryptDecryptUtil.when(() -> EncryptDecryptUtil.decrypt(Mockito.any(), Mockito.any()))
				.thenReturn("asdfghjkljhgf");

		RequestPath requestPath = Mockito.mock(RequestPath.class);
		requestPath.modifyContextPath("dfghjkl");

		Mockito.when(request.getPath()).thenReturn(requestPath);

		
		DataBufferFactory dataBufferFactory = Mockito.mock(DataBufferFactory.class);
		byte[] b = new byte[10];

		URI uri = new URI("/common/");
		Mockito.lenient().when(exchange.getRequest()).thenReturn(request);
		Mockito.lenient().when(request.mutate()).thenReturn(builder);
		Mockito.lenient().when(builder.header(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(builder);
		Mockito.lenient().when(request.getURI()).thenReturn(uri);
		Mockito.lenient().when(exchange.getResponse()).thenReturn(serverHttpResponse);
		Mockito.lenient().when(serverHttpResponse.bufferFactory()).thenReturn(dataBufferFactory);
		Mockito.lenient().when(dataBufferFactory.wrap(b)).thenReturn(null);
		Mockito.lenient().when(authConfig.getTokenttl()).thenReturn(300L);
		Mockito.lenient().when(jwtUtils.getTokenFromRequest(request)).thenReturn("jwtParser1");
		Mockito.lenient().when(jwtUtils.validateJwtToken(ArgumentMatchers.anyString(), ArgumentMatchers.any()))
		.thenReturn(new CatsCustomException("101", "success", "success"));
        Mockito.lenient().when(jwtUtils.getAllClaimsFromToken(ArgumentMatchers.any())).thenReturn(claims);
        Mockito.lenient().when(tokenService.validateToken(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(new CatsCustomException("101", "success", "success"));
		Mono<Void> mono = factory.filter(exchange, gatewayFilterChain);
		assertNull(mono);
	}

    @Test
	void filter5() throws URISyntaxException {
		ServerHttpResponse serverHttpResponse = Mockito.mock(ServerHttpResponse.class);
		ServerWebExchange exchange = Mockito.mock(ServerWebExchange.class);
		GatewayFilterChain gatewayFilterChain = Mockito.mock(GatewayFilterChain.class);
		ServerHttpRequest.Builder builder = Mockito.mock(ServerHttpRequest.Builder.class);
		Claims claims = new DefaultClaims();
		LinkedHashMap<String, Boolean> map = new LinkedHashMap<>();
		map.put("deskTopApp1", true);
		claims.put("payload", map);
		
		Mockito.lenient().when(authConfig.getSecretkey()).thenReturn("asdf");
		String[] arr = new String[1];
		arr[0] = "dfghjkl";
		Mockito.lenient().when(authConfig.getExcludeUrls()).thenReturn(arr);
		encryptDecryptUtil.when(() -> EncryptDecryptUtil.decrypt(Mockito.any(), Mockito.any()))
				.thenReturn("asdfghjkljhgf");

		RequestPath requestPath = Mockito.mock(RequestPath.class);
		requestPath.modifyContextPath("dfghjkl");

		Mockito.lenient().when(request.getPath()).thenReturn(requestPath);

		
		DataBufferFactory dataBufferFactory = Mockito.mock(DataBufferFactory.class);
		byte[] b = new byte[10];

		URI uri = new URI("/iprovision/");
		Mockito.lenient().when(exchange.getRequest()).thenReturn(request);
		Mockito.lenient().when(request.mutate()).thenReturn(builder);
		Mockito.lenient().when(builder.header(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(builder);
		Mockito.lenient().when(request.getURI()).thenReturn(uri);
		Mockito.lenient().when(exchange.getResponse()).thenReturn(serverHttpResponse);
		Mockito.lenient().when(serverHttpResponse.bufferFactory()).thenReturn(dataBufferFactory);
		Mockito.lenient().when(dataBufferFactory.wrap(b)).thenReturn(null);
		Mockito.lenient().when(authConfig.getTokenttl()).thenReturn(300L);
		Mockito.lenient().when(jwtUtils.getTokenFromRequest(request)).thenReturn("jwtParser1");
		Mockito.lenient().when(jwtUtils.validateJwtToken(ArgumentMatchers.anyString(), ArgumentMatchers.any()))
		.thenReturn(new CatsCustomException("101", "success", "success"));
        Mockito.lenient().when(jwtUtils.getAllClaimsFromToken(ArgumentMatchers.any())).thenReturn(null);
        Mockito.lenient().when(tokenService.validateToken(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(new CatsCustomException("101", "success", "success"));
		Mono<Void> mono = factory.filter(exchange, gatewayFilterChain);
		assertNull(mono);
	}

    @Test
	void filter6() throws URISyntaxException {
		ServerHttpResponse serverHttpResponse = Mockito.mock(ServerHttpResponse.class);
		ServerWebExchange exchange = Mockito.mock(ServerWebExchange.class);
		GatewayFilterChain gatewayFilterChain = Mockito.mock(GatewayFilterChain.class);
		ServerHttpRequest.Builder builder = Mockito.mock(ServerHttpRequest.Builder.class);
		Claims claims = new DefaultClaims();
		LinkedHashMap<String, Boolean> map = new LinkedHashMap<>();
		map.put("deskTopApp1", true);
		claims.put("payload", map);
		
		Mockito.lenient().when(authConfig.getSecretkey()).thenReturn("asdf");
		String[] arr = new String[1];
		arr[0] = "dfghjkl";
		Mockito.lenient().when(authConfig.getExcludeUrls()).thenReturn(arr);
		encryptDecryptUtil.when(() -> EncryptDecryptUtil.decrypt(Mockito.any(), Mockito.any()))
				.thenReturn(null);

		RequestPath requestPath = Mockito.mock(RequestPath.class);
		requestPath.modifyContextPath("dfghjkl");

		Mockito.lenient().when(request.getPath()).thenReturn(requestPath);

		
		DataBufferFactory dataBufferFactory = Mockito.mock(DataBufferFactory.class);
		byte[] b = new byte[10];

		URI uri = new URI("/iprovisionio/");
		Mockito.lenient().when(exchange.getRequest()).thenReturn(request);
		Mockito.lenient().when(request.mutate()).thenReturn(builder);
		Mockito.lenient().when(builder.header(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(builder);
		Mockito.lenient().when(request.getURI()).thenReturn(uri);
		Mockito.lenient().when(exchange.getResponse()).thenReturn(serverHttpResponse);
		Mockito.lenient().when(serverHttpResponse.bufferFactory()).thenReturn(dataBufferFactory);
		Mockito.lenient().when(dataBufferFactory.wrap(b)).thenReturn(null);
		Mockito.lenient().when(authConfig.getTokenttl()).thenReturn(300L);
		Mockito.lenient().when(jwtUtils.getTokenFromRequest(request)).thenReturn("jwtParser1");
		Mockito.lenient().when(jwtUtils.validateJwtToken(ArgumentMatchers.anyString(), ArgumentMatchers.any()))
		.thenReturn(new CatsCustomException("101", "success", "success"));
        Mockito.lenient().when(jwtUtils.getAllClaimsFromToken(ArgumentMatchers.any())).thenReturn(null);
        Mockito.lenient().when(tokenService.validateToken(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(new CatsCustomException("101", "success", "success"));
		Mono<Void> mono = factory.filter(exchange, gatewayFilterChain);
		assertNull(mono);
	}
    
    @Test
    void filter7()throws URISyntaxException {

		ServerHttpResponse serverHttpResponse = Mockito.mock(ServerHttpResponse.class);
		ServerWebExchange exchange = Mockito.mock(ServerWebExchange.class);
		GatewayFilterChain gatewayFilterChain = Mockito.mock(GatewayFilterChain.class);
		ServerHttpRequest.Builder builder = Mockito.mock(ServerHttpRequest.Builder.class);
		Claims claims = new DefaultClaims();
		LinkedHashMap<String, Boolean> map = new LinkedHashMap<>();
		map.put("deskTopApp1", true);
		claims.put("payload", map);
		
		Mockito.lenient().when(authConfig.getSecretkey()).thenReturn("asdf");
		String[] arr = new String[1];
		arr[0] = "dfghjkl";
		Mockito.lenient().when(authConfig.getExcludeUrls()).thenReturn(arr);
		encryptDecryptUtil.when(() -> EncryptDecryptUtil.decrypt(Mockito.any(), Mockito.any()))
				.thenReturn("sadfghj");

		RequestPath requestPath = Mockito.mock(RequestPath.class);
		requestPath.modifyContextPath("dfghjkl");

		Mockito.lenient().when(request.getPath()).thenReturn(requestPath);

		
		DataBufferFactory dataBufferFactory = Mockito.mock(DataBufferFactory.class);
		byte[] b = new byte[10];

		URI uri = new URI("/iprovisionio/");
		Mockito.lenient().when(exchange.getRequest()).thenReturn(request);
		Mockito.lenient().when(request.mutate()).thenReturn(builder);
		Mockito.lenient().when(builder.header(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(builder);
		Mockito.lenient().when(request.getURI()).thenReturn(null);
		Mockito.lenient().when(exchange.getResponse()).thenReturn(serverHttpResponse);
		Mockito.lenient().when(serverHttpResponse.bufferFactory()).thenReturn(dataBufferFactory);
		Mockito.lenient().when(dataBufferFactory.wrap(b)).thenReturn(null);
		Mockito.lenient().when(authConfig.getTokenttl()).thenReturn(300L);
		Mockito.lenient().when(jwtUtils.getTokenFromRequest(request)).thenReturn("jwtParser1");
		Mockito.lenient().when(jwtUtils.validateJwtToken(ArgumentMatchers.anyString(), ArgumentMatchers.any()))
		.thenReturn(new CatsCustomException("101", "success", "success"));
        Mockito.lenient().when(jwtUtils.getAllClaimsFromToken(ArgumentMatchers.any())).thenReturn(null);
        Mockito.lenient().when(tokenService.validateToken(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(new CatsCustomException("101", "success", "success"));
		Mono<Void> mono = factory.filter(exchange, gatewayFilterChain);
		assertNull(mono);
	
    	
    }
    
    @Test
   	void filter8() throws URISyntaxException {
   		ServerHttpResponse serverHttpResponse = Mockito.mock(ServerHttpResponse.class);
   		ServerWebExchange exchange = Mockito.mock(ServerWebExchange.class);
   		GatewayFilterChain gatewayFilterChain = Mockito.mock(GatewayFilterChain.class);
   		ServerHttpRequest.Builder builder = Mockito.mock(ServerHttpRequest.Builder.class);
   		Claims claims = new DefaultClaims();
   		LinkedHashMap<String, Boolean> map = new LinkedHashMap<>();
   		map.put("deskTopApp1", true);
   		claims.put("payload", map);
   		
   		Mockito.lenient().when(authConfig.getSecretkey()).thenReturn("asdf");
   		String[] arr = new String[1];
   		arr[0] = "dfghjkl";
   		Mockito.lenient().when(authConfig.getExcludeUrls()).thenReturn(arr);
   		encryptDecryptUtil.when(() -> EncryptDecryptUtil.decrypt(Mockito.any(), Mockito.any()))
   				.thenReturn("asdfghjkljhgf");

   		RequestPath requestPath = Mockito.mock(RequestPath.class);
   		requestPath.modifyContextPath("dfghjkl");

   		Mockito.lenient().when(request.getPath()).thenReturn(requestPath);

   		
   		DataBufferFactory dataBufferFactory = Mockito.mock(DataBufferFactory.class);
   		byte[] b = new byte[10];

   		URI uri = new URI("/operations/");
   		Mockito.lenient().when(exchange.getRequest()).thenReturn(request);
   		Mockito.lenient().when(request.mutate()).thenReturn(builder);
   		Mockito.lenient().when(builder.header(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(builder);
   		Mockito.lenient().when(request.getURI()).thenReturn(uri);
   		Mockito.lenient().when(exchange.getResponse()).thenReturn(serverHttpResponse);
   		Mockito.lenient().when(serverHttpResponse.bufferFactory()).thenReturn(dataBufferFactory);
   		Mockito.lenient().when(dataBufferFactory.wrap(b)).thenReturn(null);
   		Mockito.lenient().when(authConfig.getTokenttl()).thenReturn(300L);
   		Mockito.lenient().when(jwtUtils.getTokenFromRequest(request)).thenReturn("jwtParser1");
   		Mockito.lenient().when(jwtUtils.validateJwtToken(ArgumentMatchers.anyString(), ArgumentMatchers.any()))
   		.thenReturn(new CatsCustomException("101", "success", "success"));
           Mockito.lenient().when(jwtUtils.getAllClaimsFromToken(ArgumentMatchers.any())).thenReturn(claims);
           Mockito.lenient().when(tokenService.validateToken(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(new CatsCustomException("101", "success", "success"));
   		Mono<Void> mono = factory.filter(exchange, gatewayFilterChain);
   		assertNull(mono);
   	}
    @Test
   	void filter9() throws URISyntaxException {
   		ServerHttpResponse serverHttpResponse = Mockito.mock(ServerHttpResponse.class);
   		ServerWebExchange exchange = Mockito.mock(ServerWebExchange.class);
   		GatewayFilterChain gatewayFilterChain = Mockito.mock(GatewayFilterChain.class);
   		ServerHttpRequest.Builder builder = Mockito.mock(ServerHttpRequest.Builder.class);
   		Claims claims = new DefaultClaims();
   		LinkedHashMap<String, Boolean> map = new LinkedHashMap<>();
   		map.put("deskTopApp1", true);
   		claims.put("payload", map);
   		
   		Mockito.lenient().when(authConfig.getSecretkey()).thenReturn("asdf");
   		String[] arr = new String[1];
   		arr[0] = "dfghjkl";
   		Mockito.lenient().when(authConfig.getExcludeUrls()).thenReturn(arr);
   		encryptDecryptUtil.when(() -> EncryptDecryptUtil.decrypt(Mockito.any(), Mockito.any()))
   				.thenReturn("asdfghjkljhgf");

   		RequestPath requestPath = Mockito.mock(RequestPath.class);
   		requestPath.modifyContextPath("dfghjkl");

   		Mockito.lenient().when(request.getPath()).thenReturn(requestPath);

   		
   		DataBufferFactory dataBufferFactory = Mockito.mock(DataBufferFactory.class);
   		byte[] b = new byte[10];

   		URI uri = new URI("/iprovision_inventory/");
   		Mockito.lenient().when(exchange.getRequest()).thenReturn(request);
   		Mockito.lenient().when(request.mutate()).thenReturn(builder);
   		Mockito.lenient().when(builder.header(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(builder);
   		Mockito.lenient().when(request.getURI()).thenReturn(uri);
   		Mockito.lenient().when(exchange.getResponse()).thenReturn(serverHttpResponse);
   		Mockito.lenient().when(serverHttpResponse.bufferFactory()).thenReturn(dataBufferFactory);
   		Mockito.lenient().when(dataBufferFactory.wrap(b)).thenReturn(null);
   		Mockito.lenient().when(authConfig.getTokenttl()).thenReturn(300L);
   		Mockito.lenient().when(jwtUtils.getTokenFromRequest(request)).thenReturn("jwtParser1");
   		Mockito.lenient().when(jwtUtils.validateJwtToken(ArgumentMatchers.anyString(), ArgumentMatchers.any()))
   		.thenReturn(new CatsCustomException("101", "success", "success"));
           Mockito.lenient().when(jwtUtils.getAllClaimsFromToken(ArgumentMatchers.any())).thenReturn(claims);
           Mockito.lenient().when(tokenService.validateToken(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(new CatsCustomException("101", "success", "success"));
   		Mono<Void> mono = factory.filter(exchange, gatewayFilterChain);
   		assertNull(mono);
   	}
    @Test
   	void filter10() throws URISyntaxException {
   		ServerHttpResponse serverHttpResponse = Mockito.mock(ServerHttpResponse.class);
   		ServerWebExchange exchange = Mockito.mock(ServerWebExchange.class);
   		GatewayFilterChain gatewayFilterChain = Mockito.mock(GatewayFilterChain.class);
   		ServerHttpRequest.Builder builder = Mockito.mock(ServerHttpRequest.Builder.class);
   		Claims claims = new DefaultClaims();
   		LinkedHashMap<String, Boolean> map = new LinkedHashMap<>();
   		map.put("deskTopApp1", true);
   		claims.put("payload", map);
   		
   		Mockito.lenient().when(authConfig.getSecretkey()).thenReturn("asdf");
   		String[] arr = new String[1];
   		arr[0] = "dfghjkl";
   		Mockito.lenient().when(authConfig.getExcludeUrls()).thenReturn(arr);
   		encryptDecryptUtil.when(() -> EncryptDecryptUtil.decrypt(Mockito.any(), Mockito.any()))
   				.thenReturn("asdfghjkljhgf");

   		RequestPath requestPath = Mockito.mock(RequestPath.class);
   		requestPath.modifyContextPath("dfghjkl");

   		Mockito.lenient().when(request.getPath()).thenReturn(requestPath);

   		
   		DataBufferFactory dataBufferFactory = Mockito.mock(DataBufferFactory.class);
   		byte[] b = new byte[10];

   		URI uri = new URI("/catalog-service/");
   		Mockito.lenient().when(exchange.getRequest()).thenReturn(request);
   		Mockito.lenient().when(request.mutate()).thenReturn(builder);
   		Mockito.lenient().when(builder.header(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(builder);
   		Mockito.lenient().when(request.getURI()).thenReturn(uri);
   		Mockito.lenient().when(exchange.getResponse()).thenReturn(serverHttpResponse);
   		Mockito.lenient().when(serverHttpResponse.bufferFactory()).thenReturn(dataBufferFactory);
   		Mockito.lenient().when(dataBufferFactory.wrap(b)).thenReturn(null);
   		Mockito.lenient().when(authConfig.getTokenttl()).thenReturn(300L);
   		Mockito.lenient().when(jwtUtils.getTokenFromRequest(request)).thenReturn("jwtParser1");
   		Mockito.lenient().when(jwtUtils.validateJwtToken(ArgumentMatchers.anyString(), ArgumentMatchers.any()))
   		.thenReturn(new CatsCustomException("101", "success", "success"));
           Mockito.lenient().when(jwtUtils.getAllClaimsFromToken(ArgumentMatchers.any())).thenReturn(claims);
           Mockito.lenient().when(tokenService.validateToken(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(new CatsCustomException("101", "success", "success"));
   		Mono<Void> mono = factory.filter(exchange, gatewayFilterChain);
   		assertNull(mono);
   	}

    @Test
   	void filter11() throws URISyntaxException {
   		ServerHttpResponse serverHttpResponse = Mockito.mock(ServerHttpResponse.class);
   		ServerWebExchange exchange = Mockito.mock(ServerWebExchange.class);
   		GatewayFilterChain gatewayFilterChain = Mockito.mock(GatewayFilterChain.class);
   		ServerHttpRequest.Builder builder = Mockito.mock(ServerHttpRequest.Builder.class);
   		Claims claims = new DefaultClaims();
   		LinkedHashMap<String, Boolean> map = new LinkedHashMap<>();
   		map.put("deskTopApp1", true);
   		claims.put("payload", map);
   		
   		Mockito.lenient().when(authConfig.getSecretkey()).thenReturn("asdf");
   		String[] arr = new String[1];
   		arr[0] = "dfghjkl";
   		Mockito.lenient().when(authConfig.getExcludeUrls()).thenReturn(arr);
   		encryptDecryptUtil.when(() -> EncryptDecryptUtil.decrypt(Mockito.any(), Mockito.any()))
   				.thenReturn("asdfghjkljhgf");

   		RequestPath requestPath = Mockito.mock(RequestPath.class);
   		requestPath.modifyContextPath("dfghjkl");

   		Mockito.lenient().when(request.getPath()).thenReturn(requestPath);

   		
   		DataBufferFactory dataBufferFactory = Mockito.mock(DataBufferFactory.class);
   		byte[] b = new byte[10];

   		URI uri = new URI("/source/");
   		Mockito.lenient().when(exchange.getRequest()).thenReturn(request);
   		Mockito.lenient().when(request.mutate()).thenReturn(builder);
   		Mockito.lenient().when(builder.header(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(builder);
   		Mockito.lenient().when(request.getURI()).thenReturn(uri);
   		Mockito.lenient().when(exchange.getResponse()).thenReturn(serverHttpResponse);
   		Mockito.lenient().when(serverHttpResponse.bufferFactory()).thenReturn(dataBufferFactory);
   		Mockito.lenient().when(dataBufferFactory.wrap(b)).thenReturn(null);
   		Mockito.lenient().when(authConfig.getTokenttl()).thenReturn(300L);
   		Mockito.lenient().when(jwtUtils.getTokenFromRequest(request)).thenReturn("jwtParser1");
   		Mockito.lenient().when(jwtUtils.validateJwtToken(ArgumentMatchers.anyString(), ArgumentMatchers.any()))
   		.thenReturn(new CatsCustomException("101", "success", "success"));
           Mockito.lenient().when(jwtUtils.getAllClaimsFromToken(ArgumentMatchers.any())).thenReturn(claims);
           Mockito.lenient().when(tokenService.validateToken(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(new CatsCustomException("101", "success", "success"));
   		Mono<Void> mono = factory.filter(exchange, gatewayFilterChain);
   		assertNull(mono);
   	}
    
    @Test
   	void filter12() throws URISyntaxException {
   		ServerHttpResponse serverHttpResponse = Mockito.mock(ServerHttpResponse.class);
   		ServerWebExchange exchange = Mockito.mock(ServerWebExchange.class);
   		GatewayFilterChain gatewayFilterChain = Mockito.mock(GatewayFilterChain.class);
   		ServerHttpRequest.Builder builder = Mockito.mock(ServerHttpRequest.Builder.class);
   		Claims claims = new DefaultClaims();
   		LinkedHashMap<String, Boolean> map = new LinkedHashMap<>();
   		map.put("deskTopApp1", true);
   		claims.put("payload", map);
   		
   		Mockito.lenient().when(authConfig.getSecretkey()).thenReturn("asdf");
   		String[] arr = new String[1];
   		arr[0] = "dfghjkl";
   		Mockito.lenient().when(authConfig.getExcludeUrls()).thenReturn(arr);
   		encryptDecryptUtil.when(() -> EncryptDecryptUtil.decrypt(Mockito.any(), Mockito.any()))
   				.thenReturn("asdfghjkljhgf");

   		RequestPath requestPath = Mockito.mock(RequestPath.class);
   		requestPath.modifyContextPath("dfghjkl");

   		Mockito.lenient().when(request.getPath()).thenReturn(requestPath);

   		
   		DataBufferFactory dataBufferFactory = Mockito.mock(DataBufferFactory.class);
   		byte[] b = new byte[10];

   		URI uri = new URI("/sourceio/");
   		Mockito.lenient().when(exchange.getRequest()).thenReturn(request);
   		Mockito.lenient().when(request.mutate()).thenReturn(builder);
   		Mockito.lenient().when(builder.header(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(builder);
   		Mockito.lenient().when(request.getURI()).thenReturn(uri);
   		Mockito.lenient().when(exchange.getResponse()).thenReturn(serverHttpResponse);
   		Mockito.lenient().when(serverHttpResponse.bufferFactory()).thenReturn(dataBufferFactory);
   		Mockito.lenient().when(dataBufferFactory.wrap(b)).thenReturn(null);
   		Mockito.lenient().when(authConfig.getTokenttl()).thenReturn(300L);
   		Mockito.lenient().when(jwtUtils.getTokenFromRequest(request)).thenReturn("jwtParser1");
   		Mockito.lenient().when(jwtUtils.validateJwtToken(ArgumentMatchers.anyString(), ArgumentMatchers.any()))
   		.thenReturn(new CatsCustomException("101", "failed", "failed"));
           Mockito.lenient().when(jwtUtils.getAllClaimsFromToken(ArgumentMatchers.any())).thenReturn(null);
           Mockito.lenient().when(tokenService.validateToken(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(new CatsCustomException("101", "success", "success"));
   		Mono<Void> mono = factory.filter(exchange, gatewayFilterChain);
   		assertNull(mono);
   	}

}