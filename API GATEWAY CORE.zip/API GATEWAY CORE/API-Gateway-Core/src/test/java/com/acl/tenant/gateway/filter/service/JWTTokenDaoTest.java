package com.acl.tenant.gateway.filter.service;

import com.acl.tenant.gateway.filter.JWTTokenDaoImpl;
import com.cats.acl.entity.JWTToken;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;

import java.util.concurrent.TimeUnit;

@ExtendWith(MockitoExtension.class)
class JWTTokenDaoTest {

    @Mock
    RedisTemplate<String, JWTToken> redisTemplate;

    @InjectMocks
    JWTTokenDaoImpl dao;

    JWTToken jwtToken;
    HashOperations hashOperations;

    @BeforeEach
    void setUp() {
        hashOperations = Mockito.mock(HashOperations.class);
        jwtToken = new JWTToken();
        jwtToken.setToken("aaa");
        jwtToken.setId("a");
        jwtToken.setTtl(1000L);
    }

    @Test
    void saveJWTToken() {
        Mockito.when(redisTemplate.opsForHash()).thenReturn(hashOperations);
        dao.saveJWTToken(jwtToken, 30L);
        Mockito.verify(redisTemplate, Mockito.times(1)).expire("a", 30L, TimeUnit.MINUTES);
    }

    @Test
    void getJWTToken() {
        Mockito.when(redisTemplate.opsForHash()).thenReturn(hashOperations);
        dao.getJWTToken("a");
        Mockito.verify(redisTemplate, Mockito.times(1)).opsForHash();
    }

    @Test
    void updateJWTToken() {
        Mockito.when(redisTemplate.opsForHash()).thenReturn(hashOperations);
        dao.updateJWTToken(jwtToken, 1000L);
        Mockito.verify(redisTemplate, Mockito.times(1)).expire("a", 1000L, TimeUnit.MINUTES);
    }
}