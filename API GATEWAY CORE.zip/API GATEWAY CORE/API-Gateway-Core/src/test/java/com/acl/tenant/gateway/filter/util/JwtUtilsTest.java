package com.acl.tenant.gateway.filter.util;

import com.acl.tenant.gateway.entity.AuthConfig;
import com.acl.tenant.gateway.exception.CatsCustomException;
import com.acl.tenant.gateway.util.JwtUtils;
import io.jsonwebtoken.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.web.server.ServerWebExchange;

import static org.mockito.ArgumentMatchers.anyString;

@SpringBootTest
@AutoConfigureMockMvc(addFilters = false)
@ExtendWith(MockitoExtension.class)
public class JwtUtilsTest {

    @Mock
    AuthConfig authConfig;

    @InjectMocks
    JwtUtils jwtUtils;

    @Test
    void validateJwtToken() {
        try (MockedStatic<Jwts> mock = Mockito.mockStatic(Jwts.class)) {
            JwtParser jwtParser = Mockito.mock(JwtParser.class);
            JwtParser jwtParser1 = Mockito.mock(JwtParser.class);
            ServerWebExchange exchange = Mockito.mock(ServerWebExchange.class);
            mock.when(() -> Jwts.parser()).thenReturn(jwtParser);
            Mockito.when(jwtParser.setSigningKey("CATSACLSECRETKEY")).thenReturn(jwtParser1);
            Mockito.when(authConfig.getSignkey()).thenReturn("CATSACLSECRETKEY");
            CatsCustomException token = jwtUtils.validateJwtToken("token", exchange);
            Assertions.assertTrue(token.getErrorMsg().length() > 0);
        }
    }

    @Test
    void validateJwtToken1() {
        try (MockedStatic<Jwts> mock = Mockito.mockStatic(Jwts.class)) {
            JwtParser jwtParser = Mockito.mock(JwtParser.class);
            JwtParser jwtParser1 = Mockito.mock(JwtParser.class);
            ServerWebExchange exchange = Mockito.mock(ServerWebExchange.class);
            mock.when(() -> Jwts.parser()).thenReturn(jwtParser);
            Mockito.when(jwtParser.setSigningKey("CATSACLSECRETKEY")).thenReturn(jwtParser1);
            Mockito.when(authConfig.getSignkey()).thenReturn("CATSACLSECRETKEY");
            Mockito.when(jwtParser1.parseClaimsJws(anyString())).thenThrow(new SignatureException("message"));
            CatsCustomException token = jwtUtils.validateJwtToken("token", exchange);
            Assertions.assertTrue(token.getErrorMsg().length() > 0);
        }
    }

    @Test
    void validateJwtToken2() {
        try (MockedStatic<Jwts> mock = Mockito.mockStatic(Jwts.class)) {
            JwtParser jwtParser = Mockito.mock(JwtParser.class);
            JwtParser jwtParser1 = Mockito.mock(JwtParser.class);
            ServerWebExchange exchange = Mockito.mock(ServerWebExchange.class);
            mock.when(() -> Jwts.parser()).thenReturn(jwtParser);
            Mockito.when(jwtParser.setSigningKey("CATSACLSECRETKEY")).thenReturn(jwtParser1);
            Mockito.when(authConfig.getSignkey()).thenReturn("CATSACLSECRETKEY");
            Mockito.when(jwtParser1.parseClaimsJws(anyString())).thenThrow(new MalformedJwtException("message"));
            CatsCustomException token = jwtUtils.validateJwtToken("token", exchange);
            Assertions.assertTrue(token.getErrorMsg().length() > 0);
        }
    }

    @Test
    void validateJwtToken3() {
        try (MockedStatic<Jwts> mock = Mockito.mockStatic(Jwts.class)) {
            JwtParser jwtParser = Mockito.mock(JwtParser.class);
            JwtParser jwtParser1 = Mockito.mock(JwtParser.class);
            ServerWebExchange exchange = Mockito.mock(ServerWebExchange.class);
            mock.when(() -> Jwts.parser()).thenReturn(jwtParser);
            Mockito.when(jwtParser.setSigningKey("CATSACLSECRETKEY")).thenReturn(jwtParser1);
            Mockito.when(authConfig.getSignkey()).thenReturn("CATSACLSECRETKEY");
            Mockito.when(jwtParser1.parseClaimsJws(anyString())).thenThrow(new ExpiredJwtException(null, null, "message"));
            CatsCustomException token = jwtUtils.validateJwtToken("token", exchange);
            Assertions.assertTrue(token.getErrorCode().length() > 0);
        }
    }

    @Test
    void validateJwtToken4() {
        try (MockedStatic<Jwts> mock = Mockito.mockStatic(Jwts.class)) {
            JwtParser jwtParser = Mockito.mock(JwtParser.class);
            JwtParser jwtParser1 = Mockito.mock(JwtParser.class);
            ServerWebExchange exchange = Mockito.mock(ServerWebExchange.class);
            mock.when(() -> Jwts.parser()).thenReturn(jwtParser);
            Mockito.when(jwtParser.setSigningKey("CATSACLSECRETKEY")).thenReturn(jwtParser1);
            Mockito.when(authConfig.getSignkey()).thenReturn("CATSACLSECRETKEY");
            Mockito.when(jwtParser1.parseClaimsJws(anyString())).thenThrow(new UnsupportedJwtException("message"));
            CatsCustomException token = jwtUtils.validateJwtToken("token", exchange);
            Assertions.assertTrue(token.getErrorDesc().length() > 0);
        }
    }

    @Test
    void validateJwtToken5() {
        try (MockedStatic<Jwts> mock = Mockito.mockStatic(Jwts.class)) {
            JwtParser jwtParser = Mockito.mock(JwtParser.class);
            JwtParser jwtParser1 = Mockito.mock(JwtParser.class);
            ServerWebExchange exchange = Mockito.mock(ServerWebExchange.class);
            mock.when(() -> Jwts.parser()).thenReturn(jwtParser);
            Mockito.when(jwtParser.setSigningKey("CATSACLSECRETKEY")).thenReturn(jwtParser1);
            Mockito.when(authConfig.getSignkey()).thenReturn("CATSACLSECRETKEY");
            Mockito.when(jwtParser1.parseClaimsJws(anyString())).thenThrow(new IllegalArgumentException("message"));
            CatsCustomException token = jwtUtils.validateJwtToken("token", exchange);
            Assertions.assertTrue(token.getErrorMsg().length() > 0);
        }
    }

    @Test
    void getAllClaimsFromToken() {
        try (MockedStatic<Jwts> mock = Mockito.mockStatic(Jwts.class)) {
            JwtParser jwtParser = Mockito.mock(JwtParser.class);
            JwtParser jwtParser1 = Mockito.mock(JwtParser.class);
            Jws<Claims> claimsJws = Mockito.mock(Jws.class);
            mock.when(() -> Jwts.parser()).thenReturn(jwtParser);
            Mockito.when(jwtParser.setSigningKey("CATSACLSECRETKEY")).thenReturn(jwtParser1);
            Mockito.when(authConfig.getSignkey()).thenReturn("CATSACLSECRETKEY");
            Mockito.when(jwtParser1.parseClaimsJws(anyString())).thenReturn(claimsJws);
            Claims token = (Claims) jwtUtils.getAllClaimsFromToken("token");
            Assertions.assertEquals(null, token);
        }
    }

    @Test
    void getAllClaimsFromToken1() {
        try (MockedStatic<Jwts> mock = Mockito.mockStatic(Jwts.class)) {
            JwtParser jwtParser = Mockito.mock(JwtParser.class);
            JwtParser jwtParser1 = Mockito.mock(JwtParser.class);
            mock.when(() -> Jwts.parser()).thenReturn(jwtParser);
            Mockito.when(jwtParser.setSigningKey("CATSACLSECRETKEY")).thenReturn(jwtParser1);
            Mockito.when(authConfig.getSignkey()).thenReturn("CATSACLSECRETKEY");
            Mockito.when(jwtParser1.parseClaimsJws(anyString())).thenThrow(new SignatureException("message"));
            CatsCustomException token = (CatsCustomException) jwtUtils.getAllClaimsFromToken("token");
            Assertions.assertTrue(token.getErrorMsg().length() > 0);
        }
    }


    @Test
    void getAllClaimsFromToken2() {
        try (MockedStatic<Jwts> mock = Mockito.mockStatic(Jwts.class)) {
            JwtParser jwtParser = Mockito.mock(JwtParser.class);
            JwtParser jwtParser1 = Mockito.mock(JwtParser.class);
            mock.when(() -> Jwts.parser()).thenReturn(jwtParser);
            Mockito.when(jwtParser.setSigningKey("CATSACLSECRETKEY")).thenReturn(jwtParser1);
            Mockito.when(authConfig.getSignkey()).thenReturn("CATSACLSECRETKEY");
            Mockito.when(jwtParser1.parseClaimsJws(anyString())).thenThrow(new MalformedJwtException("message"));
            CatsCustomException token = (CatsCustomException) jwtUtils.getAllClaimsFromToken("token");
            Assertions.assertTrue(token.getErrorMsg().length() > 0);
        }
    }

    @Test
    void getAllClaimsFromToken3() {
        try (MockedStatic<Jwts> mock = Mockito.mockStatic(Jwts.class)) {
            JwtParser jwtParser = Mockito.mock(JwtParser.class);
            JwtParser jwtParser1 = Mockito.mock(JwtParser.class);
            mock.when(() -> Jwts.parser()).thenReturn(jwtParser);
            Mockito.when(jwtParser.setSigningKey("CATSACLSECRETKEY")).thenReturn(jwtParser1);
            Mockito.when(authConfig.getSignkey()).thenReturn("CATSACLSECRETKEY");
            Mockito.when(jwtParser1.parseClaimsJws(anyString())).thenThrow(new ExpiredJwtException(null, null, "message"));
            CatsCustomException token = (CatsCustomException) jwtUtils.getAllClaimsFromToken("token");
            Assertions.assertTrue(token.getErrorMsg().length() > 0);
        }
    }

    @Test
    void getAllClaimsFromToken4() {
        try (MockedStatic<Jwts> mock = Mockito.mockStatic(Jwts.class)) {
            JwtParser jwtParser = Mockito.mock(JwtParser.class);
            JwtParser jwtParser1 = Mockito.mock(JwtParser.class);
            mock.when(() -> Jwts.parser()).thenReturn(jwtParser);
            Mockito.when(jwtParser.setSigningKey("CATSACLSECRETKEY")).thenReturn(jwtParser1);
            Mockito.when(authConfig.getSignkey()).thenReturn("CATSACLSECRETKEY");
            Mockito.when(jwtParser1.parseClaimsJws(anyString())).thenThrow(new UnsupportedJwtException("message"));
            CatsCustomException token = (CatsCustomException) jwtUtils.getAllClaimsFromToken("token");
            Assertions.assertTrue(token.getErrorMsg().length() > 0);
        }
    }

    @Test
    void getAllClaimsFromToken5() {
        try (MockedStatic<Jwts> mock = Mockito.mockStatic(Jwts.class)) {
            JwtParser jwtParser = Mockito.mock(JwtParser.class);
            JwtParser jwtParser1 = Mockito.mock(JwtParser.class);
            mock.when(() -> Jwts.parser()).thenReturn(jwtParser);
            Mockito.when(jwtParser.setSigningKey("CATSACLSECRETKEY")).thenReturn(jwtParser1);
            Mockito.when(authConfig.getSignkey()).thenReturn("CATSACLSECRETKEY");
            Mockito.when(jwtParser1.parseClaimsJws(anyString())).thenThrow(new IllegalArgumentException("message"));
            CatsCustomException token = (CatsCustomException) jwtUtils.getAllClaimsFromToken("token");
            Assertions.assertTrue(token.getErrorMsg().length() > 0);
        }
    }

    @Test
    void getUserNameFromJwtToken() {
        try (MockedStatic<Jwts> mock = Mockito.mockStatic(Jwts.class)) {
            JwtParser jwtParser = Mockito.mock(JwtParser.class);
            JwtParser jwtParser1 = Mockito.mock(JwtParser.class);
            Jws<Claims> claimsJws = Mockito.mock(Jws.class);
            Claims claims = Mockito.mock(Claims.class);
            mock.when(() -> Jwts.parser()).thenReturn(jwtParser);
            Mockito.when(jwtParser.setSigningKey("CATSACLSECRETKEY")).thenReturn(jwtParser1);
            Mockito.when(authConfig.getSignkey()).thenReturn("CATSACLSECRETKEY");
            Mockito.when(jwtParser1.parseClaimsJws(anyString())).thenReturn(claimsJws);
            Mockito.when(claimsJws.getBody()).thenReturn(claims);
            Mockito.when(claims.getSubject()).thenReturn("claims");
            String token = jwtUtils.getUserNameFromJwtToken("token");
            Assertions.assertTrue(token.length() > 0);
        }
    }

//    @Test
    void getTokenFromRequest() {
        ServerHttpRequest serverHttpRequest = Mockito.mock(ServerHttpRequest.class);
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("Authorization", "main");

        Mockito.when(authConfig.getSecretkey()).thenReturn("xyz");
        Mockito.when(serverHttpRequest.getHeaders()).thenReturn(httpHeaders);
        String token = jwtUtils.getTokenFromRequest(serverHttpRequest);
        Assertions.assertNull(token);
    }

    @Test
    void getTokenFromRequest1() {
        ServerHttpRequest serverHttpRequest = Mockito.mock(ServerHttpRequest.class);
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("Authorizatio", "main");

        Mockito.when(serverHttpRequest.getHeaders()).thenReturn(httpHeaders);
        String token = jwtUtils.getTokenFromRequest(serverHttpRequest);
        Assertions.assertNull(token);
    }
}
