package com.acl.tenant.gateway.filter.service;

import com.acl.tenant.gateway.entity.AuthConfig;
import com.acl.tenant.gateway.exception.CatsCustomException;
import com.acl.tenant.gateway.filter.JWTTokenDaoImpl;
import com.acl.tenant.gateway.util.TokenServiceImpl;
import com.cats.acl.entity.JWTToken;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;


@ExtendWith(MockitoExtension.class)
public class TokenServiceImplTest {


    @InjectMocks
    TokenServiceImpl tokenService;

    @Mock
    JWTTokenDaoImpl dao;

    @Test
    void validateToken() {

        JWTToken jwtToken = new JWTToken();
        jwtToken.setToken("test");

        Mockito.when(dao.getJWTToken(ArgumentMatchers.any())).thenReturn(jwtToken);
        CatsCustomException data = tokenService.validateToken("test", "shashank.gupta");
        assertTrue(data.getErrorMsg().length() > 0);
    }

    @Test
    void validateToken1() {

        JWTToken jwtToken = new JWTToken();
        jwtToken.setToken("test");

        Mockito.when(dao.getJWTToken(ArgumentMatchers.any())).thenReturn(jwtToken);
        CatsCustomException data = tokenService.validateToken("t1est", "shashank.gupta");
        assertTrue(data.getErrorMsg().length() > 0);
    }

    @Test
    void validateToken2() {

        JWTToken jwtToken = new JWTToken();
        jwtToken.setToken("test");
        Mockito.when(dao.getJWTToken(ArgumentMatchers.any())).thenReturn(null);
        CatsCustomException data = tokenService.validateToken("t1est", "shashank.gupta");
        assertTrue(data.getErrorMsg().length() > 0);
    }

    // @Test
    // void validateToken3() {
    //     JWTToken jwtToken = new JWTToken();
    //     Mockito.when(dao.getJWTToken(ArgumentMatchers.any())).thenReturn(jwtToken);
    //     CatsCustomException data = tokenService.validateToken("test", "shashank.gupta");
    //     assertNull(data.getErrorMsg());
    // }

    @Test
    void saveToken() {

        JWTToken jwtToken = new JWTToken();
        jwtToken.setToken("token");
        jwtToken.setId("shashank.gupta");
        jwtToken.setTtl(1800L);

        Mockito.when(dao.getJWTToken(ArgumentMatchers.anyString())).thenReturn(jwtToken);
        tokenService.saveToken("shashank.gupta", "test", 1000L);
        Mockito.verify(dao, Mockito.times(1)).updateJWTToken(jwtToken, 1000L);
    }

    @Test
    void saveToken1() {

        JWTToken jwtToken = new JWTToken();
        jwtToken.setToken("token");
        jwtToken.setId("shashank.gupta");
        jwtToken.setTtl(1800L);

        Mockito.when(dao.getJWTToken(ArgumentMatchers.anyString())).thenReturn(jwtToken);
        Mockito.when(dao.getJWTToken(ArgumentMatchers.anyString())).thenReturn(null);
        tokenService.saveToken("shashank.gupta", "token", 1800L);
        Mockito.verify(dao, Mockito.times(1)).updateJWTToken(jwtToken, 1800L);
    }
}
