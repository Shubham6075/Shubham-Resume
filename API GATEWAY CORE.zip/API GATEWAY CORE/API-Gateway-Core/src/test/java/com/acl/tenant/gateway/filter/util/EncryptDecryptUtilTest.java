package com.acl.tenant.gateway.filter.util;

import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import com.acl.tenant.gateway.util.EncryptDecryptUtil;

@ExtendWith(MockitoExtension.class)
class EncryptDecryptUtilTest {
	
	@Test
	void encrypt1() {
		String plainText = "adminddddddddddddddddddddddddddddddddddddddddddddddd";
		String key = "sadaefffffffffffffffffffffffffffffffffffffff";
		EncryptDecryptUtil.encrypt(plainText.getBytes(), key.getBytes());
	}

	@Test
	void decrypt() {
		String plainText = "adminddddddddddddddddddddddddddddddddddddddddddddddd";
		String key = "sadaefdghjkfghhhhhhhhhhhhhhhhhhhhhhhh";
	    EncryptDecryptUtil.decrypt(plainText.getBytes(), key.getBytes());
	}
}
