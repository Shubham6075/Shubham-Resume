package com.cats.acl.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.redis.core.RedisHash;
import org.springframework.data.redis.core.TimeToLive;

import javax.persistence.Id;
import java.io.Serializable;
import java.util.concurrent.TimeUnit;

@Data
@AllArgsConstructor
@NoArgsConstructor
//@RedisHash("ACL_Tenant_Backend_Token")
public class JWTToken implements Serializable {

    @Id
    String id;
    String token;
    @TimeToLive(unit = TimeUnit.SECONDS)
    Long ttl;

}
