package com.acl.tenant.gateway.config;

import com.netflix.discovery.EurekaClient;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextClosedEvent;
import org.springframework.stereotype.Component;

@Component
public class EurekaShutdownHandler implements ApplicationListener<ContextClosedEvent> {
    private final EurekaClient eurekaClient;

    public EurekaShutdownHandler(EurekaClient eurekaClient) {
        this.eurekaClient = eurekaClient;
    }

    @Override
    public void onApplicationEvent(ContextClosedEvent event) {
        eurekaClient.shutdown(); // deregister on shutdown
    }
}