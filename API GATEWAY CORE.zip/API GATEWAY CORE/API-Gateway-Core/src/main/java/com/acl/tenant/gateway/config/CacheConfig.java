package com.acl.tenant.gateway.config;

import com.cats.acl.entity.JWTToken;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.data.redis.RedisProperties;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.RedisPassword;
import org.springframework.data.redis.connection.RedisSentinelConfiguration;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceClientConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.repository.configuration.EnableRedisRepositories;
import org.springframework.data.redis.serializer.JdkSerializationRedisSerializer;
import org.springframework.data.redis.serializer.RedisSerializationContext;

import java.time.Duration;

@Configuration("cacheConfig")
@ConditionalOnProperty(prefix = "spring", name = "cache.type", havingValue = "redis")
@EnableRedisRepositories
@EnableCaching
@RequiredArgsConstructor
public class CacheConfig {

    private final RedisProperties redisProperties;
    @Value("${auth.cache}")
    private long ttl;

    @Value("${sentinel.used}")
    private boolean isSentinel;

    @Bean
//    @Profile({ "uat", "SITA_dev" })
    protected LettuceConnectionFactory redisConnectionFactory() {
        System.out.println("Shashank "+redisProperties.getPort());
        if (isSentinel) {
            RedisSentinelConfiguration sentinelConfig = new RedisSentinelConfiguration()
                    .master(redisProperties.getSentinel().getMaster());
            redisProperties.getSentinel().getNodes().forEach(s -> sentinelConfig.sentinel(s, redisProperties.getPort()));
            sentinelConfig.setPassword(RedisPassword.of(redisProperties.getPassword()));
            return new LettuceConnectionFactory(sentinelConfig, LettuceClientConfiguration.defaultConfiguration());
        } else {
            RedisStandaloneConfiguration redisConf = new RedisStandaloneConfiguration();
            redisConf.setHostName(redisProperties.getHost());
            redisConf.setPort(redisProperties.getPort());
            redisConf.setPassword(RedisPassword.of(redisProperties.getPassword()));
            return new LettuceConnectionFactory(redisConf);
        }
    }

    @Bean
    @Primary
    public CacheManager cacheManager1(RedisConnectionFactory redisConnectionFactory) {
        JdkSerializationRedisSerializer redisSerializer = new JdkSerializationRedisSerializer(
                getClass().getClassLoader());

        RedisCacheConfiguration redisCacheConfiguration = RedisCacheConfiguration.defaultCacheConfig()
                .entryTtl(Duration.ofSeconds(ttl))
                .serializeValuesWith(RedisSerializationContext.SerializationPair.fromSerializer(redisSerializer));

        redisCacheConfiguration.usePrefix();

        return RedisCacheManager.RedisCacheManagerBuilder.fromConnectionFactory(redisConnectionFactory)
                .cacheDefaults(redisCacheConfiguration).build();
    }

    @Bean
    public RedisTemplate<String, JWTToken> redisTemplate(){
        RedisTemplate<String, JWTToken> empTemplate = new RedisTemplate<>();
        empTemplate.setConnectionFactory(redisConnectionFactory());
        return empTemplate;
    }

}