package com.acl.tenant.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@EnableEurekaClient
@SpringBootApplication
public class AclTenantGateway {

	public static void main(String[] args) {
		SpringApplication.run(AclTenantGateway.class, args);
	}

}
