package com.acl.tenant.gateway.filter;

import com.cats.acl.entity.JWTToken;

public interface JWTTokenDao {
    void saveJWTToken(JWTToken emp, Long ttl);
    JWTToken getJWTToken(String id);
    void updateJWTToken(JWTToken emp, Long ttl);
}
