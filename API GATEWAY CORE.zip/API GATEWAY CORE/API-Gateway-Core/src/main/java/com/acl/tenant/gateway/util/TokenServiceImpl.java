package com.acl.tenant.gateway.util;

import com.acl.tenant.gateway.entity.AuthConfig;
import com.acl.tenant.gateway.exception.CatsCustomException;
import com.acl.tenant.gateway.filter.JWTTokenDao;
import com.cats.acl.entity.JWTToken;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Service
public class TokenServiceImpl implements TokenService {

    public static final Logger LOGGER = LogManager.getLogger(TokenServiceImpl.class);

    @Autowired
    JWTTokenDao dao;


    @Override
    public CatsCustomException validateToken(String jwt, String username) {
        CatsCustomException catsCustomException = null;
        try {

            JWTToken token = dao.getJWTToken(username);

            if (token != null) {

                LOGGER.info(token.getToken());
                if (token.getToken().trim().equals(jwt.trim())) {
                    catsCustomException = new CatsCustomException(HttpStatus.UNAUTHORIZED.toString(), "success", "success");
                } else {
                    catsCustomException = new CatsCustomException(HttpStatus.UNAUTHORIZED.toString(), "Session has expired due to invalid JWT !!!", "session.expired");

                }
            } else {
                catsCustomException = new CatsCustomException(HttpStatus.UNAUTHORIZED.toString(), "Session has expired due to invalid JWT !!!", "session.expired");
            }
        } catch (Exception e) {
            catsCustomException = new CatsCustomException(HttpStatus.UNAUTHORIZED.toString(), e.getMessage(), e.getLocalizedMessage());
        }
        return catsCustomException;
    }

    @Override
    public void saveToken(String loginId, String token, Long ttl) {
        JWTToken jwtToken = null;
        JWTToken optToken = dao.getJWTToken(loginId);
        if (optToken != null) {
            jwtToken = optToken;
        } else {
            jwtToken = new JWTToken();
            jwtToken.setId(loginId);
            jwtToken.setToken(token);
        }
        if (ttl != 0) {
            jwtToken.setTtl(ttl);
        }

        dao.updateJWTToken(jwtToken,ttl);
    }
}
