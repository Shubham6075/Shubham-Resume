package com.acl.tenant.gateway.entity;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name = "gateway_routes_master")
public class RouteDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "route_id")
    private Integer id;

    @Column(name = "route_name")
    private String routeName;

    @Column(name = "route_path_pattern")
    private String pathPattern;

    @Column(name = "product_uri")
    private String uri;
}
