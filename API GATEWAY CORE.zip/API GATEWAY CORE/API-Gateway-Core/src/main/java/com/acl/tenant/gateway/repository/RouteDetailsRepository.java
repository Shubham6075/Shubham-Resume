package com.acl.tenant.gateway.repository;

import com.acl.tenant.gateway.entity.RouteDetails;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RouteDetailsRepository extends JpaRepository<RouteDetails,Integer> {
}
