package com.acl.tenant.gateway.constants;


public class Constants {



    private Constants() {

    }


    public static final String ENCRYPT_CIPHER ="AES/CBC/PKCS5Padding";
    public static final String DECRYPT_CIPHER ="AES/CBC/PKCS5PADDING";
    public static final long JWT_TOKEN_VALIDITY = 5 * 60 * 60;
    public static final String SECRET="java";
    public static final String EXPIRED_TOKEN= "Expired JWT token";
    public static final String LOGOUT_MSG="Logged out Successfully !!!";
    public static final String INVALIDATE_MSG="Invalid JWT token !!";
    public static final String VALIDATE_MSG="Token is valid !!";
    public static final String NO_TOKEN="There is no token present in request, kindly send the token";
    public static final String INVALID_TOKEN="Token is invalid";
    public static final String USER_UNAUTHORIZED="User is unauthorized";
    public static final String SUFFIX_USERNAME="-APP";
    public static final String IDASHBOARD_PRODUCT_ID="12";

}
