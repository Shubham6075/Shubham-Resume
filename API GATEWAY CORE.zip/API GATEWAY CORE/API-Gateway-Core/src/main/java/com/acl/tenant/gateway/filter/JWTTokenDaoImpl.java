package com.acl.tenant.gateway.filter;

import com.cats.acl.entity.JWTToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Repository;

import java.util.concurrent.TimeUnit;

@Repository
public class JWTTokenDaoImpl implements JWTTokenDao{

    private final String hashReference= "ACL_Tenant_Backend_Token";

    @Autowired
    RedisTemplate<String, JWTToken> redisTemplate;

    @Override
    public void saveJWTToken(JWTToken emp, Long ttl) {
        redisTemplate.opsForHash().putIfAbsent(emp.getId(), hashReference, emp);
        redisTemplate.opsForHash().put(emp.getId(), hashReference,emp);
        if (ttl != 0)
            redisTemplate.expire(emp.getId(),30, TimeUnit.MINUTES);
    }

    @Override
    public JWTToken getJWTToken(String id) {
        return (JWTToken)redisTemplate.opsForHash().get(id,hashReference);
    }

    @Override
    public void updateJWTToken(JWTToken emp, Long ttl) {
        redisTemplate.opsForHash().put(emp.getId(), hashReference,emp);
        if (ttl != 0)
            redisTemplate.expire(emp.getId(),ttl, TimeUnit.MINUTES);
    }
}
