package com.acl.tenant.gateway.filter;

import com.acl.tenant.gateway.constants.Constants;
import com.acl.tenant.gateway.entity.AuthConfig;
import com.acl.tenant.gateway.exception.CatsCustomException;
import com.acl.tenant.gateway.util.EncryptDecryptUtil;
import com.acl.tenant.gateway.util.JwtUtils;
import com.acl.tenant.gateway.util.TokenService;
import com.acl.tenant.gateway.util.Utility;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import io.jsonwebtoken.Claims;
import lombok.Getter;
import lombok.Setter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.*;

@Component
public class AuthPreFilter extends AbstractGatewayFilterFactory<AuthPreFilter.Config> {

    public static final Logger LOGGER = LogManager.getLogger(AuthPreFilter.class);
    @Autowired
    private JwtUtils jwtUtils;

    @Autowired
    private TokenService tokenService;

    @Autowired
    AuthConfig authConfig;

    public AuthPreFilter() {
        super(Config.class);
    }

    @Override
    public GatewayFilter apply(Config config) {

        return (exchange, chain) -> {
            return filter(exchange, chain);
        };
    }

    @Getter
    @Setter
    public static class Config {
        private String name;
    }

    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain)  {
        ServerHttpRequest request = (ServerHttpRequest) exchange.getRequest();

       String encryptedToken = jwtUtils.getTokenFromRequest(request);

        if (encryptedToken == null) {
            encryptedToken = request.getQueryParams().getOrDefault("token", Collections.singletonList("")).get(0).toString();
            try {
                encryptedToken = encryptedToken != null ? URLDecoder.decode(encryptedToken, String.valueOf(StandardCharsets.UTF_8)) : null;
            } catch (Exception e){
                LOGGER.error("token decoding "+encryptedToken);
                return getResponse(exchange, null, HttpStatus.UNAUTHORIZED.toString(), Constants.USER_UNAUTHORIZED, Constants.INVALID_TOKEN);
            }
        }
       
        if (encryptedToken != null) {
            try {
            	 String token =  EncryptDecryptUtil.decrypt(encryptedToken.trim().getBytes(),
                         authConfig.getSecretkey().getBytes());



                 ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
               LOGGER.error("URL outside if: "+request.getURI());
                Object customObject = null;
                if (/*request.getURI().getPath().contains("/pro_watch/api/v2/") ||*/
                        request.getURI().getPath().contains("/desktop/app/") ||
                        request.getURI().getPath().contains("/iprocess/") ||
                        request.getURI().getPath().contains("/bff/") ||
                        request.getURI().getPath().contains("/common/") ||
                        request.getURI().getPath().contains("/iprovision/") ||
                        request.getURI().getPath().contains("/operations/") ||
                        request.getURI().getPath().contains("/iprovision_inventory/") ||
                        request.getURI().getPath().contains("/iprovision_inventory_sdn/") ||
                        request.getURI().getPath().contains("/catalog-service/") ||
                        request.getURI().getPath().contains("/workstation/") ||
                        request.getURI().getPath().contains("/source/") ||
                        request.getURI().getPath().contains("/isense-config/") ||
                        request.getURI().getPath().contains("/idashboard/") ||
                        request.getURI().getPath().contains("/ui_builder/api/") ||
                        request.getURI().getPath().contains("/scheduler_service/") ||
                        request.getURI().getPath().contains("/db_operations_service/") ||
                        request.getURI().getPath().contains("/ui-builder-service/") ||
                        request.getURI().getPath().contains("/task_service/") ||
                        request.getURI().getPath().contains("/workflow_service/") ||
                        request.getURI().getPath().contains("/notification_service/") ||
                        request.getURI().getPath().contains("/organisation_service/")||
                        request.getURI().getPath().contains("/logging_services/api/")||
                        request.getURI().getPath().contains("/sd-platform/iprovision_inventory/")||
                        request.getURI().getPath().contains("/sd-platform/operations/")||
                        request.getURI().getPath().contains("/sd-platform/logging_services/")||
                        request.getURI().getPath().contains("/adapter/")||
                        request.getURI().getPath().contains("/threat-console/")||
                        request.getURI().getPath().contains("/socket.io/")
                ){
                    LOGGER.error("URL inside if: "+request.getURI());
                    CatsCustomException validateJwtToken = jwtUtils.validateJwtToken(token, exchange);
                    String json = ow.writeValueAsString(validateJwtToken);
                    if (validateJwtToken.getErrorMsg().equalsIgnoreCase("success")) {
                        LOGGER.error("URL inside validateJwtToken if: "+request.getURI());
                        String username = jwtUtils.getUserNameFromJwtToken(token);
                        Claims claims = (Claims) jwtUtils.getAllClaimsFromToken(token);
                        LinkedHashMap<String,String> map = (LinkedHashMap<String,String>)claims.get("payload");
                        if (map != null && map.containsKey("deskTopApp") && Boolean.TRUE.equals(map.get("deskTopApp"))) {
                            username = username+ Constants.SUFFIX_USERNAME;
                        }
                        CatsCustomException validateToken = tokenService.validateToken(encryptedToken, username);
                        if (validateToken.getErrorMsg().equalsIgnoreCase("success")) {
                            LOGGER.error("URL inside validateToken if: "+request.getURI());
                            customObject = jwtUtils.getAllClaimsFromToken(token);
                            if (!((Claims)customObject).containsKey("token_id")) {
                                String path = request.getPath().toString();
                                if (!needToUpdateSessionTime(path)) {
                                    if (Boolean.TRUE.equals(map.get("deskTopApp"))) {
                                        tokenService.saveToken(username, encryptedToken, 0L);
                                    } else {
                                        LOGGER.error("save token: "+request.getURI());
                                        tokenService.saveToken(username, encryptedToken, authConfig.getTokenttl());
                                    }
                                }
                            }
                        } else {
                            LOGGER.error("URL inside validateToken else: "+request.getURI());
                            String validateTokenJson = ow.writeValueAsString(validateToken);
                            return getResponse(exchange, validateTokenJson, HttpStatus.UNAUTHORIZED.toString(), "", "");
                        }
                    } else {
                        LOGGER.error("URL inside validateJwtToken else: "+request.getURI());
                        return getResponse(exchange, json, HttpStatus.UNAUTHORIZED.toString(), "", "");
                    }
                }

                if (customObject == null) {
                    customObject = jwtUtils.getAllClaimsFromToken(token);
                    LOGGER.error("customObject: "+request.getURI());
                }
                if (customObject instanceof Claims) {
                    Claims claims = (Claims) customObject;
                    if (claims != null && !claims.containsKey("token_id")) {
                        LOGGER.error("inside claims: "+request.getURI());
                        String userName = Utility.formatUserName(String.valueOf(claims.get("sub")));
                        String userId = String.valueOf(((LinkedHashMap<String,String>)claims.get("payload")).get("userId"));
                        ObjectMapper objectMapper = new ObjectMapper();
                        String respData = objectMapper.writeValueAsString(((LinkedHashMap<String,String>)claims.get("payload")).get("permissions"));
                        LinkedHashMap respMap = objectMapper.readValue(respData, LinkedHashMap.class);
                        LOGGER.error("2nd inside claims: "+request.getURI());
//                        List<LinkedHashMap<String,String>> roleList = (List<LinkedHashMap<String, String>>) respMap.get("product_role");
                        String basedRole= "";
                        if (respMap != null)
                            basedRole = (String) respMap.get("role");

                        List<Map<String, String>> productRoles = (List<Map<String, String>>) respMap.get("product_role");
                        LOGGER.error("3rd inside claims just product: "+request.getURI());
                        if (productRoles != null) {
                            LOGGER.error("inside productRoles: "+request.getURI());
                            Optional<Map<String, String>> matchingRole = productRoles.stream()
                                    .filter(role -> Constants.IDASHBOARD_PRODUCT_ID.equals(role.get("product_id")))
                                    .findFirst();
                            LOGGER.error("inside 2nd productRoles: "+request.getURI());
                            if (matchingRole.isPresent()) {
                                String roleNameForIDashboard = matchingRole.get().get("role_name");
                                exchange.getRequest().mutate().header("productRole", roleNameForIDashboard).build();
                                LOGGER.error("exchange: "+request.getURI());

                            }
                        }

//                        Map<String, Object> permissionsData = extractPermissionsForProduct((List<Map<String, Object>>) ((Map<String, Object>) claims.get("payload")).get("productPermissions"), request);
                        String tenantId = String.valueOf(((LinkedHashMap<String,String>)claims.get("payload")).get("tenantId"));
                        LOGGER.error("get tenant id: "+request.getURI());
                        /*if (permissionsData.size()!=0) {
                            exchange.getRequest().mutate().header("permissions",   permissionsData.get("permissions").toString()).build();
                            exchange.getRequest().mutate().header("productId",  permissionsData.get("productId").toString()).build();
                        }*/
                        exchange.getRequest().mutate().header("userName", userName).build();
                        exchange.getRequest().mutate().header("userId", userId).build();
                        exchange.getRequest().mutate().header("role", basedRole).build();
                        exchange.getRequest().mutate().header("aclTenantId", tenantId).build();
                    }
                } else {
                    LOGGER.error("claims: "+request.getURI());
                    CatsCustomException exception = (CatsCustomException) customObject;
                    String json = ow.writeValueAsString(exception);
                    return getResponse(exchange, json, HttpStatus.UNAUTHORIZED.toString(), "", "");
                }

            } catch (Exception e) {
                LOGGER.error("Exception : "+request.getURI());
                return getResponse(exchange, null, HttpStatus.UNAUTHORIZED.toString(), e.getMessage(), e.getLocalizedMessage());
            }
        } else {
            LOGGER.error("claims: "+request.getURI());
            return getResponse(exchange, null, HttpStatus.UNAUTHORIZED.toString(), Constants.USER_UNAUTHORIZED, Constants.NO_TOKEN);
        }
        LOGGER.error("just before chain filter: "+request.getURI());
        return chain.filter(exchange);
    }

    private Mono<Void> getResponse(ServerWebExchange exchange, String json, String statusCode, String errMsg, String errDesc) {
        try {
            if (json == null) {
                CatsCustomException catsCustomException = new CatsCustomException(statusCode, errMsg, errDesc);
                ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
                json = ow.writeValueAsString(catsCustomException);
            }

            ServerHttpResponse res = exchange.getResponse();
            res.setStatusCode(HttpStatus.UNAUTHORIZED);
            byte[] response = json.getBytes(StandardCharsets.UTF_8);
            DataBuffer buffer = exchange.getResponse().bufferFactory().wrap(response);
            return exchange.getResponse().writeWith(Flux.just(buffer));
        } catch (Exception e) {
            ServerHttpResponse response = exchange.getResponse();
            response.setStatusCode(HttpStatus.UNAUTHORIZED);
            return response.setComplete();
        }
    }

    private boolean checkModuleFeaturePermission(String token) {

        return false;
    }

    public boolean needToUpdateSessionTime(String path) {
        if (path == null || path.trim().isEmpty()) {
            return false;
        }

        List<String> pathList = Arrays.asList(authConfig.getExcludeUrls());
        if (pathList.contains(path)) {
            return true;
        } else {
            return false;
        }
    }

    private Map<String, Object> extractPermissionsForProduct(List<Map<String, Object>> productPermissionsList, ServerHttpRequest request) {
        Map<String, Object> permissionData = new HashMap<>();
        String requestPath = request.getURI().getPath(); //  /notification_service/notification/get-notifications-count
        for (Map<String, Object> productPermission : productPermissionsList) {
            String productName = (String) productPermission.get("product_name");
            String primaryProductName = productName.contains("/") ? productName.split("/")[1] : productName;
            if (requestPath.contains("/" + primaryProductName + "/")) {
                permissionData.put("productId", productPermission.get("product_id"));
                permissionData.put("permissions", productPermission.get("permissions"));
                break;
            }
        }
        return permissionData;
    }
}


