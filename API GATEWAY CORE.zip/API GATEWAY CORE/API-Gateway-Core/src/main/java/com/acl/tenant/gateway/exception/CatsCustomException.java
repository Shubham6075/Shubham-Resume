package com.acl.tenant.gateway.exception;

public class CatsCustomException {

    private static final long serialVersionUID = 1L;
    private final String errorCode;
    private final String errorMsg;

    private final String errorDescription;

    public CatsCustomException(String errorCode, String errorMsg, String errorDescription) {
        this.errorCode = errorCode;
        this.errorMsg = errorMsg;
        this.errorDescription = errorDescription;
    }

    public String getErrorMsg() {
        return errorMsg;
    }


    public String getErrorCode() {
        return errorCode;
    }

    public String getErrorDesc() {
        return errorDescription;
    }

}
