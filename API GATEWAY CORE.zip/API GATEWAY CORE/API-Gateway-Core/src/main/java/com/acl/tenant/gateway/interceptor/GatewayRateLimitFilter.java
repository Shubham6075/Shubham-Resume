package com.acl.tenant.gateway.interceptor;

import com.acl.tenant.gateway.exception.CatsCustomException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.var;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.core.Ordered;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import reactor.core.publisher.Mono;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;

@Component
@RequiredArgsConstructor
public class GatewayRateLimitFilter implements GlobalFilter, Ordered {

    private static final List<String> EXCLUDED_PATHS = Arrays.asList("/swagger-ui/", "/v3/api-docs/", "/login", "/forgot-password", "/reset-password");
    private final GatewayRateLimiter aclRateLimiter;
    private final ObjectMapper objectMapper;

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {

        String path = exchange.getRequest().getURI().getPath();

        if (isExcluded(path)) {
            return chain.filter(exchange);
        }

        String userId = exchange.getRequest().getHeaders().getFirst("userId");

        boolean isAuthenticated = userId != null;

        String key = userId;

        if (!isAuthenticated) {

            var remoteAddress = exchange.getRequest().getRemoteAddress();

            if (remoteAddress != null && remoteAddress.getAddress() != null) {
                key = remoteAddress.getAddress().getHostAddress();
            } else {
                key = "unknown";
            }
        }

        return aclRateLimiter.isAllowed(key, isAuthenticated).flatMap(allowed -> {

            if (!allowed) {
                return handleRateLimitExceeded(exchange);
            }

            return chain.filter(exchange);
        });
    }

    private Mono<Void> handleRateLimitExceeded(ServerWebExchange exchange) {

        CatsCustomException error = new CatsCustomException(
                HttpStatus.TOO_MANY_REQUESTS.toString(),
                "rate limit exceeded",
                "Too many requests. Please try again later."
        );

        try {
            byte[] bytes = objectMapper
                    .writeValueAsString(error)
                    .getBytes(StandardCharsets.UTF_8);

            exchange.getResponse().setStatusCode(HttpStatus.TOO_MANY_REQUESTS);
            exchange.getResponse().getHeaders().setContentType(MediaType.APPLICATION_JSON);

            return exchange.getResponse()
                    .writeWith(Mono.just(
                            exchange.getResponse()
                                    .bufferFactory()
                                    .wrap(bytes)
                    ));

        } catch (Exception e) {
            return exchange.getResponse().setComplete();
        }
    }

    private boolean isExcluded(String path) {
        return EXCLUDED_PATHS.stream().anyMatch(path::startsWith);
    }

    @Override
    public int getOrder() {
        return -2;
    }
}
