package com.acl.tenant.gateway.util;

import com.acl.tenant.gateway.entity.AuthConfig;
import com.acl.tenant.gateway.exception.CatsCustomException;
import io.jsonwebtoken.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Component
public class JwtUtils {
    public static final Logger LOGGER = LogManager.getLogger(JwtUtils.class);
    @Autowired
    private AuthConfig authConfig;
    
    //retrieve expiration date from jwt token
   /* public Date getExpirationDateFromToken(String token) {
        return getClaimFromToken(token, Claims::getExpiration);
    }

    public <T> T getClaimFromToken(String token, Function<Claims, T> claimsResolver) {
        final Claims claims = (Claims) getAllClaimsFromToken(token);
        return claimsResolver.apply(claims);
    }*/

    // for retrieveing any information from token we will need the secret key
    public Object getAllClaimsFromToken(String token) {

        String errMsg = null;

        try {
            return Jwts.parser().setSigningKey(authConfig.getSignkey()).parseClaimsJws(token).getBody();
        } catch (SignatureException ex) {
            LOGGER.info("Invalid JWT Signature");
            errMsg = "Invalid JWT Signature";
            return new CatsCustomException(HttpStatus.UNAUTHORIZED.toString(), errMsg, ex.getMessage());
        } catch (MalformedJwtException ex) {
            LOGGER.info("Invalid JWT token");
            errMsg = "Invalid JWT token";
            return new CatsCustomException(HttpStatus.UNAUTHORIZED.toString(), errMsg, ex.getMessage());
        } catch (ExpiredJwtException ex) {
            LOGGER.info("Expired JWT token");
//            redis.deleteByToken(token);
            errMsg = "Expired JWT token";
            return new CatsCustomException(HttpStatus.UNAUTHORIZED.toString(), errMsg, ex.getMessage());
        } catch (UnsupportedJwtException ex) {
            LOGGER.info("Unsupported JWT exception");
            errMsg = "Unsupported JWT exception";
            return new CatsCustomException(HttpStatus.UNAUTHORIZED.toString(), errMsg, ex.getMessage());
        } catch (IllegalArgumentException ex) {
            LOGGER.info("Jwt claims string is empty");
            errMsg = "Jwt claims string is empty";
            return new CatsCustomException(HttpStatus.UNAUTHORIZED.toString(), errMsg, ex.getMessage());
        }
    }

    //check if the token has expired
   /* public Boolean isTokenExpired(String token) {
        final Date expiration = getExpirationDateFromToken(token);
        return expiration.before(new Date());
    }*/

    //generate token for user
   /* public String generateToken(JwtPayload payload) {
        Map<String, Object> claims = new HashMap<>();
        claims.put("payload", payload);
        return doGenerateToken(claims, payload.getLoginId());
    }*/

   /* private String doGenerateToken(Map<String, Object> claims, String subject) {

        return Jwts.builder().setClaims(claims).setSubject(subject).setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis() + authConfig.getTokenexpiretime())).addClaims(claims)
                .signWith(SignatureAlgorithm.HS512, authConfig.getSignkey()).compact();
    }

    public boolean hasRole(String token, String role) {
        Claims claims = (Claims) getAllClaimsFromToken(token);
        List<String> roleAllowed = Arrays.asList(role.split(";"));
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> roles = (List<Map<String, Object>>) claims.get("roles");
        List<String> roleList = roles.stream().map(map -> map.get("role").toString()).collect(Collectors.toList());
        Optional<String> result = roleList.stream().filter(roleAllowed::contains).findFirst();
        return result.isPresent();
    }*/

    public String getUserNameFromJwtToken(String token) {
        return Jwts.parser().setSigningKey(authConfig.getSignkey()).parseClaimsJws(token).getBody().getSubject();
    }

    public CatsCustomException validateJwtToken(String authToken, ServerWebExchange exchange/*, HttpServletRequest httpServletRequest*/) {
        try {
            Jwts.parser().setSigningKey(authConfig.getSignkey()).parseClaimsJws(authToken);
            return new CatsCustomException(HttpStatus.UNAUTHORIZED.toString(), "success","success");
        } catch (SignatureException ex) {
            LOGGER.info("Invalid JWT Signature");
            return new CatsCustomException(HttpStatus.UNAUTHORIZED.toString(), "Invalid JWT Signature", ex.getMessage());
        } catch (MalformedJwtException ex) {
            LOGGER.info("Invalid JWT token");
            return new CatsCustomException(HttpStatus.UNAUTHORIZED.toString(), "Invalid JWT token", ex.getMessage());
        } catch (ExpiredJwtException ex) {
            LOGGER.info("Expired JWT token");
            return new CatsCustomException(HttpStatus.UNAUTHORIZED.toString(), "Expired JWT token", ex.getMessage());
        } catch (UnsupportedJwtException ex) {
            LOGGER.info("Unsupported JWT exception");
            return new CatsCustomException(HttpStatus.UNAUTHORIZED.toString(), "Unsupported JWT exception", ex.getMessage());
        } catch (IllegalArgumentException ex) {
            LOGGER.info("Jwt claims string is empty");
            return new CatsCustomException(HttpStatus.UNAUTHORIZED.toString(), "Jwt claims string is empty", ex.getMessage());
        }
    }

    /*public String generateTokenFromUsername(String username) {

        return Jwts.builder().setSubject(username).setIssuedAt(new Date())
                .setExpiration(new Date((new Date()).getTime() + authConfig.getTokenexpiretime()))
                .signWith(SignatureAlgorithm.HS512, authConfig.getSignkey()).compact();
    }


    public Map<String, Object> addClaims(String token) {
        String claims = Jwts.builder().setSubject(token)
                .setExpiration(new Date(System.currentTimeMillis() + authConfig.getTokenexpiretime()))
                .claim("Role", "Admin").claim("Department", "Product development")
                .signWith(SignatureAlgorithm.HS512, authConfig.getSignkey()).compact();
        Map<String, Object> claim = new HashMap<>();
        claim.put("claims", token + claims);
        return claim;
    }*/

    public String getTokenFromRequest(ServerHttpRequest request) {
        if (!request.getHeaders().containsKey("Authorization")) {
            return null;
        }
        String authHeader = request.getHeaders().getOrEmpty("Authorization").get(0);
        if (authHeader == null) {
            return null;
        }
        return authHeader.replace("Bearer", "");
    }

    /*public JwtPayload getPayLoad(String token) {
        Claims claims = getAllClaimsFromToken(token);
        if (claims != null) {
        @SuppressWarnings("unchecked")
        Map<String, Object> payload = (Map<String, Object>) claims.get("payload");
        ObjectMapper mapper = new ObjectMapper();
        return mapper.convertValue(payload, JwtPayload.class);
        }
        return null;
    }*/

}