package com.acl.tenant.gateway.repository;

//@Repository
//public interface JWTTokenRepository extends CrudRepository<JWTToken, String> {
//
//    public JWTToken deleteJwtToken(String loginId);
//
//    public JWTToken deleteByToken(String token);
//
//
//}
