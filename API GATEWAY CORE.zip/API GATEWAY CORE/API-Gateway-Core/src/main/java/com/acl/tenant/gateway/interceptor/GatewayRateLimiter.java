package com.acl.tenant.gateway.interceptor;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Range;
import org.springframework.data.redis.core.ReactiveStringRedisTemplate;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.time.Instant;

@Component
@RequiredArgsConstructor
public class GatewayRateLimiter {

    private final ReactiveStringRedisTemplate redisTemplate;

    @Value("${rate-limiter.public.maxRequests}")
    private int publicMaxRequests;

    @Value("${rate-limiter.public.windowInSeconds}")
    private int publicWindowInSeconds;

    @Value("${rate-limiter.authenticated.maxRequests}")
    private int authMaxRequests;

    @Value("${rate-limiter.authenticated.windowInSeconds}")
    private int authWindowInSeconds;

    public Mono<Boolean> isAllowed(String key, boolean isAuthenticated) {

        String redisKey = "rate_limiter:" + key;

        int maxRequests = isAuthenticated ? authMaxRequests : publicMaxRequests;
        int windowInSeconds = isAuthenticated ? authWindowInSeconds : publicWindowInSeconds;

        long now = Instant.now().getEpochSecond();
        long windowStart = now - windowInSeconds;

        Range<Double> range = Range.closed(0.0, (double) windowStart);

        return redisTemplate.opsForZSet().removeRangeByScore(redisKey, range).then(redisTemplate.opsForZSet().size(redisKey)).defaultIfEmpty(0L).flatMap(count -> {

            if (count >= maxRequests) {
                return Mono.just(false);
            }

            return redisTemplate.opsForZSet().add(redisKey, String.valueOf(now), (double) now).then(redisTemplate.expire(redisKey, Duration.ofSeconds(windowInSeconds + 10))).thenReturn(true);
        });
    }

}
