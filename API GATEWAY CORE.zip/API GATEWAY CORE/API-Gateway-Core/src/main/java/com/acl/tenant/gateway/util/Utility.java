package com.acl.tenant.gateway.util;

//import org.apache.commons.lang.StringUtils;
import org.springframework.util.StringUtils;

import java.util.Arrays;
import java.util.stream.Collectors;

public class Utility {


    public static String formatUserName(String userName) {

        String user = null;

        if (null != userName) {

            userName = userName.replace("_", " ");

            String[] arrStr = userName.split("[\\s@&.?$+-]+");

            user = Arrays.stream(arrStr).map(StringUtils::capitalize).collect(Collectors.joining(" "));

            user = user.trim();

        }

        return user;

    }
}
