package com.acl.tenant.gateway.util;

import com.acl.tenant.gateway.exception.CatsCustomException;

public interface TokenService {


    CatsCustomException validateToken(String jwt, String username);

    void saveToken(String loginId, String token, Long ttl);

}