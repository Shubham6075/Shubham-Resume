package com.acl.tenant.gateway.entity;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;


@Data
@Component
@ConfigurationProperties(prefix = "auth")
@PropertySource("classpath:auth.properties")
public class AuthConfig {
    private String secretkey;
    private Long maxattempt;
    private Long tokenexpiretime;
    private String signkey;
    private long tokenttl;
    private String message;
    private String[] excludeUrls;
   
}
