#!/bin/sh

# startup.sh - startup script for the server docker image

echo "Starting AclGateway server"

/app/AclGateway/host_entry.sh $HOSTS


export config_file=

if [ "$SENTINEL" = "true" ];
then
    echo "CONFIG_PROP set. Using a sentinel Redis: $SENTINEL"
    export config_file="/app/AclGateway/application-sentinel.properties"
elif [ "$SENTINEL" = "false"  ]; then
     echo "elif Using a default Redis: $SENTINEL"
     export config_file="/app/AclGateway/application.properties"
else
    echo "CONFIG_PROP set Using a default Redis: $SENTINEL"
    export config_file="/app/AclGateway/application.properties"
fi

echo "hosts: $HOSTS"
echo "DB_IP: $DB_IP"
echo "DB_PORT: $DB_PORT"
echo "DB_NAME: $DB_NAME"
echo "DB_USER: $DB_USER"
echo "DB_PASS: $DB_PASS"

echo "EUREKA_URL: $EUREKA_URL"
echo "SENTINEL: $SENTINEL"
echo "REDIS_HOST: $REDIS_HOST"
echo "REDISH_SENTINEL_MASTER: $REDISH_SENTINEL_MASTER"
echo "REDISH_SENTINEL_NODES: $REDISH_SENTINEL_NODES"
echo "ETLT_SOURCE_URL: $ETLT_SOURCE_URL"
echo "ISENSE_CONFIG: $ISENSE_CONFIG"
echo "ADAPTER_SERVICE_URL: $ADAPTER_SERVICE_URL"
echo "SOCKET_URI: $SOCKET_URI"



sed -i "s;##DB_IP##;$DB_IP;" $config_file
sed -i "s;##DB_PORT##;$DB_PORT;" $config_file
sed -i "s;##DB_NAME##;$DB_NAME;" $config_file
sed -i "s;##DB_USER##;$DB_USER;" $config_file
sed -i "s;##DB_PASS##;$DB_PASS;" $config_file
sed -i "s;##REDIS_HOST##;$REDIS_HOST;" $config_file
sed -i "s;##REDISH_SENTINEL_MASTER##;$REDISH_SENTINEL_MASTER;" $config_file
sed -i "s;##REDISH_SENTINEL_NODES##;$REDISH_SENTINEL_NODES;" $config_file
sed -i "s;##SENTINEL##;$SENTINEL;" $config_file
sed -i "s;##ADAPTER_SERVICE_URL##;$ADAPTER_SERVICE_URL;" $config_file
sed -i "s;##SOCKET_URI##;$SOCKET_URI;" $config_file

sed -i "s;##EUREKA_URL##;$EUREKA_URL;" $config_file

sed -i "s;##ETLT_SOURCE_URL##;$ETLT_SOURCE_URL;" $config_file
sed -i "s;##ISENSE_CONFIG##;$ISENSE_CONFIG;" $config_file

echo "Using java options config: $JAVA_OPTS"

java ${JAVA_OPTS} -jar  -Dspring.config.location=$config_file  /app/AclGateway/acl-tenant-gateway-*-SNAPSHOT.jar 2>&1 | tee -a /app/AclGateway/server.log
