package com.acl.tenant.gateway.service;

import com.acl.tenant.gateway.entity.RouteDetails;
import com.acl.tenant.gateway.repository.RouteDetailsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GatewayRouteService {
    @Autowired
    RouteDetailsRepository gatewayRouteRepository;

    public List<RouteDetails> getAllRoutes() {
        return gatewayRouteRepository.findAll(Sort.by(Sort.Direction.ASC, "id"));
    }
}