package com.acl.tenant.gateway.config;

import com.acl.tenant.gateway.entity.RouteDetails;
import com.acl.tenant.gateway.filter.AuthPreFilter;
import com.acl.tenant.gateway.service.GatewayRouteService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.filter.factory.DedupeResponseHeaderGatewayFilterFactory;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Configuration
public class GatewayRouteConfig {

    public static final Logger LOGGER = LogManager.getLogger(GatewayRouteConfig.class);
    private final RouteLocatorBuilder routeLocatorBuilder;
    @Autowired
    private GatewayRouteService gatewayRouteService;
    @Autowired
    private AuthPreFilter authPreFilter;

    public GatewayRouteConfig(RouteLocatorBuilder routeLocatorBuilder) {
        this.routeLocatorBuilder = routeLocatorBuilder;
    }

    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }

    @Bean
    public RouteLocator customRouteLocator(RouteLocatorBuilder routeLocatorBuilder) {
        List<RouteDetails> routeEntities = gatewayRouteService.getAllRoutes();
        RouteLocatorBuilder.Builder builder = routeLocatorBuilder.routes();

        for (RouteDetails routeEntity : routeEntities) {
            builder.route(routeEntity.getRouteName(), r -> {
                String pathPattern = routeEntity.getPathPattern();
                String uri = routeEntity.getUri();
                if (pathPattern.equals("/tenant/acl/**") || pathPattern.equals("/core/acl/**")
                || pathPattern.equals("/api/cpanel/**")
                        || pathPattern.equals("/api/user-management/**")
                        || pathPattern.equals("/threat-console/**")
                        || pathPattern.equals("/workstation/**")
                        || pathPattern.equals("/adapter/**")
                        || pathPattern.equals("/integrations/**")
                        || pathPattern.equals("/api/**")
                        || pathPattern.equals("/pro_watch/api/v2/**")
                        || pathPattern.equals("/api/user-logging/**")
                ) {
                    return r.path(pathPattern).uri(uri);
                } else if (pathPattern.equals("/socket.io/**")) {
                    return r.path(pathPattern).filters(f -> f.filter((exchange, chain) -> authPreFilter.filter(exchange, chain).flatMap(serverPath -> {
                                if (serverPath != null && serverPath.equals(routeEntity.getRouteName())) {
                                    return chain.filter(exchange);
                                } else {
                                    LOGGER.info("Unauthorized access to route: {}", routeEntity.getRouteName());
                                    exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
                                    return exchange.getResponse().setComplete();
                                }
                            })).setRequestHeader("Connection", "Upgrade")
                            .setRequestHeader("Upgrade", "websocket").dedupeResponseHeader("Access-Control-Allow-Origin",
                                    DedupeResponseHeaderGatewayFilterFactory.Strategy.RETAIN_FIRST.toString())
                            .dedupeResponseHeader("Access-Control-Allow-Credentials",
                                    DedupeResponseHeaderGatewayFilterFactory.Strategy.RETAIN_FIRST.toString())).uri(uri);

                } else {
                    return r.path(pathPattern).filters(f -> f.filter((exchange, chain) -> authPreFilter.filter(exchange, chain).flatMap(serverPath -> {
                        if (serverPath != null && serverPath.equals(routeEntity.getRouteName())) {
                            return chain.filter(exchange);
                        } else {
                            LOGGER.info("Unauthorized access to route: {}", routeEntity.getRouteName());
                            exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
                            return exchange.getResponse().setComplete();
                        }
                    })).dedupeResponseHeader("Access-Control-Allow-Origin",
                            DedupeResponseHeaderGatewayFilterFactory.Strategy.RETAIN_FIRST.toString())
                            .dedupeResponseHeader("Access-Control-Allow-Credentials",
                                    DedupeResponseHeaderGatewayFilterFactory.Strategy.RETAIN_FIRST.toString())).uri(uri);
                }
            });
        }
        return builder.build();
    }
}