#!/usr/bin/env bash
set -euo pipefail
set -x  # Enable debug output for tracing

BUILD_NUMBER="${1:-}"
if [ -z "${BUILD_NUMBER}" ] || [ -z "${AZURE_TOKEN}" ]; then
    echo "Usage: $0 <BUILD_NUMBER> (AZURE_TOKEN must be set as an environment variable)"
    exit 2
fi

REPO_URL="https://dev.azure.com/CATS4U/Devops/_git/argocd"
GIT_USER_NAME="CATS4U"
BRANCH="in2it_cad_prod"
APP_DIR="apigateway"
YAML_FILE="apiGateway.yml"

# Configure Git user
git config --global user.email "cats4u@in2ittech.com"
git config --global user.name "CATS4U"

# Remove existing argocd directory
echo "Removing existing argocd directory"
rm -rf argocd

# Clone the repository
echo "Cloning repository: ${REPO_URL} (branch: ${BRANCH})"
if ! git clone --depth 1 --branch "${BRANCH}" "https://${GIT_USER_NAME}:${AZURE_TOKEN}@${REPO_URL#https://}" argocd; then
    echo "ERROR: Failed to clone repository"
    exit 1
fi

# Change to the application directory
echo "Changing to directory: argocd/${APP_DIR}"
if ! cd "argocd/${APP_DIR}"; then
    echo "ERROR: App directory not found: ${APP_DIR}"
    ls -la argocd
    exit 1
fi

# Check if YAML file exists
echo "Checking for YAML file: ${YAML_FILE}"
if [ ! -f "${YAML_FILE}" ]; then
    echo "ERROR: YAML file not found: ${YAML_FILE}"
    ls -la
    exit 1
fi

# Display current content of YAML file
echo "Current content of ${YAML_FILE}:"
cat "${YAML_FILE}"

# Extract the old tag, stripping comments and whitespace
old_tag=$(grep 'image:.*infocats4uai/api-gateway-prod-backend' "${YAML_FILE}" | head -n1 | cut -d ':' -f 3 | sed 's/[[:space:]]*#.*//' | tr -d ' ' || true)
echo "Extracted old_tag: '${old_tag}'"

# Update the image tag
if [ -n "${old_tag}" ]; then
    echo "Updating image tag from '${old_tag}' to '${BUILD_NUMBER}'"
    if ! sed -i "s|\(image:.*infocats4uai/api-gateway-prod-backend:\)${old_tag}\([[:space:]]*#.*\)*|\1${BUILD_NUMBER}\2|g" "${YAML_FILE}"; then
        echo "ERROR: Failed to update image tag in ${YAML_FILE}"
        exit 1
    fi
else
    echo "No old tag found, attempting to replace any tag for infocats4uai/api-gateway-uat-backend"
    if ! sed -i -E "s|(image:[[:space:]]*infocats4uai/api-gateway-prod-backend:)[^[:space:]]+([[:space:]]*#.*)*|\1${BUILD_NUMBER}\2|g" "${YAML_FILE}"; then
        echo "ERROR: Failed to update image tag in ${YAML_FILE}"
        exit 1
    fi
fi

# Display updated content of YAML file
echo "Updated content of ${YAML_FILE}:"
cat "${YAML_FILE}"

# Check for changes
echo "Checking for changes in ${YAML_FILE}"
if git diff --quiet; then
    echo "No change detected"
else
    echo "Changes detected, committing and pushing"
    git add "${YAML_FILE}"
    if ! git commit -m "Update deployment image to version ${BUILD_NUMBER}"; then
        echo "ERROR: Failed to commit changes"
        exit 1
    fi
    if ! git push "https://${GIT_USER_NAME}:${AZURE_TOKEN}@${REPO_URL#https://}" "HEAD:${BRANCH}"; then
        echo "ERROR: Failed to push changes"
        exit 1
    fi
fi

echo "Update deployment completed."